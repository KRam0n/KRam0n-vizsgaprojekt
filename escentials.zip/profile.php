<?php
// Ha szükséges, betöltheted a konfigurációt:
// include("config.php");

echo <<<'HTML'
<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profil - Escentials</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:wght@300;400;600&display=swap" rel="stylesheet">
    <!-- Egyedi stílusok -->
    <style>
        body {
            background: linear-gradient(135deg, #f5f7fa, #c3cfe2);
            font-family: 'Josefin Sans', sans-serif;
            color: #333;
        }
        .navbar-custom {
            background-color: #5d5c61;
        }
        .navbar-custom .navbar-brand,
        .navbar-custom .nav-link {
            color: #fff;
        }
        .navbar-custom .nav-link:hover {
            color: #f8b500;
        }
        main.container {
            margin-top: 120px;
        }
        h1,
        h2 {
            text-align: center;
            margin-bottom: 30px;
        }
        .order-card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            background-color: #fff;
            margin-bottom: 20px;
            transition: transform 0.2s ease;
        }
        .order-card:hover {
            transform: translateY(-3px);
        }
        .order-card .card-body {
            padding: 20px;
        }
        .order-card h5 {
            font-weight: 600;
            color: #5d5c61;
        }
        .order-card p {
            margin: 0;
            font-size: 0.95rem;
        }
        .order-card ul {
            list-style: none;
            padding: 0;
        }
        .order-card ul li {
            background: #f8f9fa;
            margin-bottom: 5px;
            padding: 5px 10px;
            border-radius: 5px;
        }
    </style>
</head>
<body>
    <!-- Navigációs sáv -->
    <nav class="navbar navbar-expand-lg navbar-custom fixed-top">
        <div class="container">
            <a class="navbar-brand" href="#">Escentials</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Navigáció megnyitása">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item"><a class="nav-link" href="index.php">Főoldal</a></li>
                    <li class="nav-item"><a class="nav-link" href="profile.php">Profil</a></li>
                    <li class="nav-item"><a class="nav-link" href="logout.php">Kilépés</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <main class="container">
        <h1>Profil</h1>
        <h2>Rendeléseim</h2>
        <div id="ordersContainer" class="row">
            <!-- Itt jelennek meg a rendelési kártyák -->
        </div>
    </main>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            let currentUser = JSON.parse(localStorage.getItem('currentUser'));
            if (!currentUser) {
                window.location.href = "login.php";
                return;
            }

            // Rendelésadatok betöltése localStorage-ből
            const ordersKey = "orders_" + currentUser.email;
            let orders = JSON.parse(localStorage.getItem(ordersKey)) || [];
            const container = document.getElementById('ordersContainer');

            if (orders.length === 0) {
                container.innerHTML = "<p class='text-center'>Nincs leadott rendelés.</p>";
            } else {
                orders.forEach(order => {
                    const colDiv = document.createElement("div");
                    colDiv.className = "col-md-6";
                    colDiv.innerHTML = `
                <div class="card order-card">
                  <div class="card-body">
                    <h5 class="card-title">Rendelés dátuma: ${new Date(order.timestamp).toLocaleString()}</h5>
                    <p><strong>Fizetési mód:</strong> ${order.paymentMethod}</p>
                    <p><strong>Összeg:</strong> ${order.total}$</p>
                    <p><strong>Termékek:</strong></p>
                    <ul>
                      ${order.items.map(item => `<li>${item.name} (x${item.quantity})${item.price ? " - " + item.price + "$" : ""}</li>`).join('')}
                    </ul>
                  </div>
                </div>
              `;
                    container.appendChild(colDiv);
                });
            }
        });
    </script>
</body>
</html>
HTML;
?>