<?php
include("config.php");

echo <<<'HTML'
<!DOCTYPE html>
<html lang="hu">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <title>Fizetés - Escentials</title>
    <!-- SEO meta tag-ek -->
    <meta name="description" content="Escentials - Fedezd fel a legjobb parfümöket, melyek garantáltan elvarázsolnak. Kiváló minőség, egyedi illatkompozíciók." />
    <meta name="keywords" content="parfüm, illat, luxus, Escentials, drogéria, minőségi parfüm" />
    <meta name="author" content="Escentials" />
    <!-- Bootstrap CSS, Swiper, Egyéb stílusok, Google Fonts & Font Awesome -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.css" />
    <link rel="stylesheet" type="text/css" href="css/vendor.css" />
    <link rel="stylesheet" type="text/css" href="style.css" />
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:wght@200;300;400;500;600;700&family=Jost:wght@200;300;400;500&display=swap" rel="stylesheet" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet" />
</head>

<body class="bg-body" data-bs-spy="scroll" data-bs-target="#navbar" data-bs-root-margin="0px 0px -40%" data-bs-smooth-scroll="true" tabindex="0">

    <!-- Header és navigáció -->
    <header id="header" class="site-header text-white bg-primary fixed-top bg-black fixed">
        <nav id="header-nav" class="navbar navbar-expand-lg">
            <div class="container-fluid">
                <!-- Logó kép helyett szöveg -->
                <a class="navbar-brand" href="index.php" style="background: transparent; color: white; font-size: 1.8rem; font-weight: bold;">
                    EScentials
                </a>
                <button class="navbar-toggler d-flex d-lg-none order-3 p-2 border-0 shadow-none" type="button"
                    data-bs-toggle="offcanvas" data-bs-target="#bdNavbar" aria-controls="bdNavbar" aria-expanded="false"
                    aria-label="Toggle navigation">
                    <svg class="navbar-icon" width="50" height="50">
                        <use xlink:href="#navbar-icon"></use>
                    </svg>
                </button>
                <div class="offcanvas offcanvas-end" tabindex="-1" id="bdNavbar" aria-labelledby="bdNavbarOffcanvasLabel">
                    <div class="offcanvas-header px-4 pb-0">
                        <!-- Ugyanez az offcanvas menüben -->
                        <a class="navbar-brand" href="index.php" style="background: transparent; color: white; font-size: 1.8rem; font-weight: bold;">
                            EScentials
                        </a>
                        <button type="button" class="btn-close btn-close-black" data-bs-dismiss="offcanvas" aria-label="Close"
                            data-bs-target="#bdNavbar"></button>
                    </div>
                    <div class="offcanvas-body">
                        <ul class="navbar-nav justify-content-end flex-grow-1 gap-5 pe-3">
                            <li class="nav-item">
                                <a class="nav-link p-0" href="index.php">Kezdőlap</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link p-0" href="termekek.php">Termékek</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link p-0" href="cart.php">Kosár</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </nav>
    </header>

    <!-- Fő tartalom: Fizetési / Szállítási adatok -->
    <main class="container" style="margin-top: 120px;">
        <h1 class="mb-4">Fizetés</h1>
        <div class="row">
            <!-- Bal oldali rész: Vásárló adatainak űrlapja -->
            <div class="col-lg-8">
                <form id="checkoutForm">
                    <div class="mb-3">
                        <label for="fullName" class="form-label">Név</label>
                        <input type="text" class="form-control" id="fullName" placeholder="Teljes név" required />
                    </div>
                    <div class="mb-3">
                        <label for="address" class="form-label">Szállítási cím</label>
                        <input type="text" class="form-control" id="address" placeholder="Utca, házszám, város, irányítószám" required />
                    </div>
                    <div class="mb-3">
                        <label for="phone" class="form-label">Telefonszám</label>
                        <input type="tel" class="form-control" id="phone" placeholder="+1..." required />
                    </div>
                    <hr class="my-4" />
                    <h4 class="mb-3">Fizetési mód</h4>
                    <div class="form-check mb-2">
                        <input class="form-check-input" type="radio" name="paymentMethod" id="cashOnDelivery" value="utánvétes" checked />
                        <label class="form-check-label" for="cashOnDelivery">Utánvétes fizetés</label>
                    </div>
                    <div class="form-check mb-4">
                        <input class="form-check-input" type="radio" name="paymentMethod" id="creditCard" value="bankkártyás" />
                        <label class="form-check-label" for="creditCard">Bankkártyás fizetés</label>
                    </div>

                    <!-- Bankkártyás űrlap mezők (alapértelmezetten rejtve) -->
                    <div id="cardPaymentFields" style="display: none;">
                        <div class="mb-3">
                            <label for="cardNumber" class="form-label">Kártyaszám</label>
                            <input type="text" class="form-control" id="cardNumber" placeholder="XXXX XXXX XXXX XXXX" />
                        </div>
                        <div class="row">
                            <div class="col mb-3">
                                <label for="cardExpiry" class="form-label">Lejárat (HH/ÉÉ)</label>
                                <input type="text" class="form-control" id="cardExpiry" placeholder="MM/YY" />
                            </div>
                            <div class="col mb-3">
                                <label for="cardCVC" class="form-label">CVC</label>
                                <input type="text" class="form-control" id="cardCVC" placeholder="CVC" />
                            </div>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-dark btn-lg w-100 mt-4">Fizetés</button>
                </form>
            </div>

            <!-- Jobb oldali rész: Rendelés összesítő -->
            <div class="col-lg-4">
                <div class="p-4 border bg-light">
                    <h4 class="mb-3">Rendelés összesítő</h4>
                    <ul id="checkoutSummary" class="list-group mb-3">
                        <!-- Itt jelennek meg a termékek/árak a localStorage alapján -->
                    </ul>
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <span class="fs-5">Összesen:</span>
                        <span class="fs-4 fw-bold" id="summaryTotal">0$</span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Rendelés leadása után visszajelzés (alapértelmezetten rejtve) -->
        <div class="mt-5" id="orderFeedback" style="display: none;">
            <div class="alert alert-success fs-5" role="alert">
                <strong>Köszönjük!</strong> A rendelését fogadtuk.
            </div>
        </div>
    </main>

    <!-- Lábléc -->
    <footer class="text-center py-3">
        <p>&copy; 2025 Escentials</p>
    </footer>

    <!-- JavaScript fájlok -->
    <script src="js/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.js"></script>
    <script src="js/plugins.js"></script>
    <script src="js/script.js"></script>

    <!-- Fizetési logika (mock) -->
    <script>
        // A kosár összesítő megjelenítése
        function displayCartSummary() {
            let cart = JSON.parse(localStorage.getItem('cart')) || [];
            const checkoutSummary = document.getElementById('checkoutSummary');
            const summaryTotal = document.getElementById('summaryTotal');

            checkoutSummary.innerHTML = '';
            let subtotal = 0;

            cart.forEach(item => {
                const { name, price, quantity } = item;
                const itemTotal = price * quantity;
                subtotal += itemTotal;

                const li = document.createElement('li');
                li.className = 'list-group-item d-flex justify-content-between align-items-center';
                li.innerHTML = `
          <div>${name} (x${quantity})</div>
          <strong>${itemTotal}$</strong>
        `;
                checkoutSummary.appendChild(li);
            });

            // Vegösszeg: termékek ára + szállítás (ha létezik szállítási opció)
            const shipping = parseInt(document.getElementById('shippingSelect')?.value, 10) || 0;
            const total = subtotal + shipping;
            summaryTotal.textContent = `${total}$`;
        }

        // Radio gombok: bankkártyás fizetés esetén megjelenítjük a kártyaadat mezőket
        const cashOnDeliveryRadio = document.getElementById('cashOnDelivery');
        const creditCardRadio = document.getElementById('creditCard');
        const cardPaymentFields = document.getElementById('cardPaymentFields');

        cashOnDeliveryRadio.addEventListener('change', () => {
            if (cashOnDeliveryRadio.checked) {
                cardPaymentFields.style.display = 'none';
            }
        });

        creditCardRadio.addEventListener('change', () => {
            if (creditCardRadio.checked) {
                cardPaymentFields.style.display = 'block';
            }
        });

        // A form elküldése (submit)
        const checkoutForm = document.getElementById('checkoutForm');
        checkoutForm.addEventListener('submit', (e) => {
            e.preventDefault(); // Ne töltse újra az oldalt

            // Ellenőrizzük a fizetési módot
            const selectedPayment = document.querySelector('input[name="paymentMethod"]:checked').value;

            if (selectedPayment === 'bankkártyás') {
                // Bankkártyás fizetés esetén ellenőrizzük a kártyaadatokat
                const cardNumber = document.getElementById('cardNumber').value.trim();
                const cardExpiry = document.getElementById('cardExpiry').value.trim();
                const cardCVC = document.getElementById('cardCVC').value.trim();

                if (!cardNumber || !cardExpiry || !cardCVC) {
                    alert('Kérjük, töltsd ki a kártyaadatokat!');
                    return;
                }
            }

            // Kosár és végösszeg kiszámítása
            let cart = JSON.parse(localStorage.getItem('cart')) || [];
            let subtotal = 0;
            cart.forEach(item => {
                subtotal += item.price * item.quantity;
            });
            const shipping = parseInt(document.getElementById('shippingSelect')?.value, 10) || 0;
            let total = subtotal + shipping;
            const couponCode = document.getElementById('couponCode')?.value.trim();
            if (couponCode === 'DISCOUNT10') {
                total = Math.round(total * 0.9);
            }

            // Rendelés objektum létrehozása
            const order = {
                timestamp: new Date().toISOString(),
                items: cart,
                total: total,
                shipping: shipping,
                paymentMethod: selectedPayment
            };

            // Ha a felhasználó be van jelentkezve, mentjük az order-t
            let currentUser = JSON.parse(localStorage.getItem('currentUser'));
            if (currentUser && currentUser.email) {
                const ordersKey = 'orders_' + currentUser.email;
                let orders = JSON.parse(localStorage.getItem(ordersKey)) || [];
                orders.push(order);
                localStorage.setItem(ordersKey, JSON.stringify(orders));
            }

            if (selectedPayment === 'bankkártyás') {
                alert('Sikeres fizetés! Köszönjük a rendelést.');
            } else {
                alert('Köszönjük! A rendelését fogadtuk, és utánvéttel fog fizetni.');
            }
            // Töröljük a kosarat és frissítjük az oldalt
            localStorage.removeItem('cart');
            document.getElementById('orderFeedback').style.display = 'block';
            checkoutForm.style.display = 'none';
        });

        // Eseményfigyelő a szállítási opció változására (ha a shippingSelect létezik)
        const shippingSelect = document.getElementById('shippingSelect');
        if (shippingSelect) {
            shippingSelect.addEventListener('change', displayCartSummary);
        }

        // Betöltéskor jelenítsük meg az összesítőt
        window.addEventListener('DOMContentLoaded', displayCartSummary);
    </script>

    <!-- Szállítási opciók script (ha szükséges) -->
    <script>
        // Ha a HTML-ben nem szerepel a shippingSelect, itt hozzáadhatod, vagy ennek megfelelően módosíthatod a kosár összesítő logikát.
    </script>
</body>

</html>
HTML;
?>