<?php
echo <<<'HTML'
<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Regisztráció - Escentials</title>
    <!-- SEO meta tag-ek -->
    <meta name="description" content="Escentials - Fedezd fel a legjobb parfümöket, melyek garantáltan elvarázsolnak. Kiváló minőség, egyedi illatkompozíciók.">
    <meta name="keywords" content="parfüm, illat, luxus, Escentials, drogéria, minőségi parfüm">
    <meta name="author" content="Escentials">
    <!-- Linkek, stílusok -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" 
          integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.css" />
    <link rel="stylesheet" type="text/css" href="css/vendor.css">
    <link rel="stylesheet" type="text/css" href="style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:wght@200;300;400;500;600;700&family=Jost:wght@200;300;400;500&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <!-- Firebase SDK -->
    <script src="https://www.gstatic.com/firebasejs/9.14.0/firebase-app.js"></script>
    <script src="https://www.gstatic.com/firebasejs/9.14.0/firebase-database.js"></script>
    <style>
        body {
            background: #eee;
            margin: 0;
            padding: 0;
        }
        .custom-container {
            max-width: 400px;
            margin: 6rem auto;
            background: #fff;
            padding: 2rem;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            color: #000;
        }
        .custom-container h1 {
            font-size: 2rem;
            text-align: center;
            margin-bottom: 1.5rem;
        }
    </style>
</head>
<body>
    <div class="custom-container">
        <h1>Regisztráció</h1>
        <form id="registrationForm">
            <div class="mb-3">
                <label for="email" class="form-label">Email cím</label>
                <input type="email" class="form-control" id="email" required>
            </div>
            <div class="mb-3">
                <label for="username" class="form-label">Felhasználónév</label>
                <input type="text" class="form-control" id="username" required>
            </div>
            <div class="mb-3">
                <label for="password" class="form-label">Jelszó</label>
                <input type="password" class="form-control" id="password" required>
            </div>
            <button type="submit" class="btn btn-primary w-100">Regisztráció</button>
        </form>
        <p class="text-center mt-3">
            Már regisztráltál?
            <a href="login.php">Bejelentkezés</a>
        </p>
    </div>
    <script>
        // Regisztrációs form submit eseménykezelése
        document.getElementById('registrationForm').addEventListener('submit', function (e) {
            e.preventDefault();
            const email = document.getElementById('email').value.trim();
            const username = document.getElementById('username').value.trim();
            const password = document.getElementById('password').value;
            if (!email || !username || !password) {
                alert("Kérjük, töltsd ki az összes mezőt!");
                return;
            }
            // Olvassuk ki a már létező felhasználókat a localStorage-ből
            let users = JSON.parse(localStorage.getItem('users')) || [];
            // Ellenőrizzük, hogy a megadott email már regisztrálva van-e
            const userExists = users.find(user => user.email === email);
            if (userExists) {
                alert("Ez az email cím már regisztrálva van!");
                return;
            }
            // Új felhasználó objektum létrehozása
            const newUser = {
                email: email,
                username: username,
                password: password // Valós alkalmazásban soha ne tárold plain text-ben!
            };
            // Felhasználó hozzáadása és mentése a localStorage-be
            users.push(newUser);
            localStorage.setItem('users', JSON.stringify(users));
            alert("Sikeres regisztráció! Kérjük, jelentkezz be.");
            window.location.href = "login.php";
        });
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
</body>
</html>
HTML;
?>