<?php
include("config.php");

echo <<<'HTML'
<!DOCTYPE html>
<html lang="hu">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Termékek - Escentials</title>
    <!-- SEO meta tag-ek -->
    <meta name="description" content="Escentials - Fedezd fel a legjobb parfümöket, melyek garantáltan elvarázsolnak. Kiváló minőség, egyedi illatkompozíciók.">
    <meta name="keywords" content="parfüm, illat, luxus, Escentials, drogéria, minőségi parfüm">
    <meta name="author" content="Escentials">
    <!-- Linkek, stílusok -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.css" />
    <link rel="stylesheet" type="text/css" href="css/vendor.css">
    <link rel="stylesheet" type="text/css" href="style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Josefin+Sans:wght@200;300;400;500;600;700&family=Jost:wght@200;300;400;500&display=swap"
        rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
</head>

<body class="bg-body" data-bs-spy="scroll" data-bs-target="#navbar" data-bs-root-margin="0px 0px -40%"
    data-bs-smooth-scroll="true" tabindex="0">
    <!-- Header és navigáció -->
    <header id="header" class="site-header text-white bg-primary fixed-top bg-black fixed">
        <nav id="header-nav" class="navbar navbar-expand-lg">
            <div class="container-fluid">
                <!-- Logó kép helyett szöveg -->
                <a class="navbar-brand" href="index.php"
                    style="background: transparent; color: white; font-size: 1.8rem; font-weight: bold;">
                    EScentials
                </a>
                <button class="navbar-toggler d-flex d-lg-none order-3 p-2 border-0 shadow-none" type="button"
                    data-bs-toggle="offcanvas" data-bs-target="#bdNavbar" aria-controls="bdNavbar" aria-expanded="false"
                    aria-label="Toggle navigation">
                    <svg class="navbar-icon" width="50" height="50">
                        <use xlink:href="#navbar-icon"></use>
                    </svg>
                </button>
                <div class="offcanvas offcanvas-end" tabindex="-1" id="bdNavbar"
                    aria-labelledby="bdNavbarOffcanvasLabel">
                    <div class="offcanvas-header px-4 pb-0">
                        <!-- Ugyanez az offcanvas menüben -->
                        <a class="navbar-brand" href="index.php"
                            style="background: transparent; color: white; font-size: 1.8rem; font-weight: bold;">
                            EScentials
                        </a>
                        <button type="button" class="btn-close btn-close-black" data-bs-dismiss="offcanvas"
                            aria-label="Close" data-bs-target="#bdNavbar"></button>
                    </div>
                    <div class="offcanvas-body">
                        <!-- Csak a szükséges menüpontok: Kezdőlap, Profil és Kosár -->
                        <ul class="navbar-nav justify-content-end flex-grow-1 gap-5 pe-3">
                            <li class="nav-item">
                                <a class="nav-link p-0" href="index.php">Kezdőlap</a>
                            </li>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle p-0" href="#" id="accountDropdown" role="button"
                                    data-bs-toggle="dropdown" aria-expanded="false">
                                    <i class="fas fa-user"></i> Profil
                                </a>
                                <ul class="dropdown-menu" aria-labelledby="accountDropdown" id="accountMenu">
                                    <li><a class="dropdown-item" href="profile.php">Rendeléseim</a></li>
                                    <li><a class="dropdown-item" href="logout.php">Kilépés</a></li>
                                </ul>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link p-0" href="kosar.php">
                                    <i class="fas fa-shopping-cart"></i> Kosár
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </nav>
    </header>

    <!-- Fő tartalom -->
    <main class="products container my-lg-6" style="margin-top: 120px;">
        <h2 class="text-center mb-4">Parfüm Kínálat</h2>
        <!-- Szűrők -->
        <div class="mb-4 d-flex justify-content-center gap-3 flex-wrap">
            <!-- Kategória szűrő -->
            <select id="genderFilter" class="form-select w-auto">
                <option value="all" selected>Összes</option>
                <option value="male">Férfi parfümök</option>
                <option value="female">Női parfümök</option>
                <option value="unisex">Unisex parfümök</option>
            </select>
            <!-- Ár szerinti rendezés -->
            <select id="priceSort" class="form-select w-auto">
                <option value="default" selected>Ár sorrend (alapértelmezett)</option>
                <option value="asc">Ár: Alacsony -> Magas</option>
                <option value="desc">Ár: Magas -> Alacsony</option>
            </select>
        </div>
        <div class="row" id="productsRow">
            <!-- Példa termékek – minden kártyának legyen data-gender és data-price attribútuma -->
            <!-- Termék 1 - férfi parfüm, ára 200 -->
            <div class="col-md-4 mb-4 product-card" data-gender="male" data-price="200">
                <div class="card">
                    <img src="images/parfume1.jpg" class="card-img-top" alt="Parfüm 1">
                    <div class="card-body">
                        <h5 class="card-title">Parfüm 1</h5>
                        <p class="card-text">Egy elegáns illat, mely tökéletes választás mindennapokra.</p>
                        <p class="card-text fw-bold">Ár: 200$</p>
                        <div class="d-flex gap-2">
                            <button class="btn btn-primary" onclick="addToCart('Parfüm 1', 200)">Kosárba helyezés</button>
                            <button class="btn btn-outline-secondary" onclick="reviewProduct('Parfüm 1')">Vélemények</button>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Termék 2 - női parfüm, ára 200 -->
            <div class="col-md-4 mb-4 product-card" data-gender="female" data-price="200">
                <div class="card">
                    <img src="images/parfume2.jpg" class="card-img-top" alt="Parfüm 2">
                    <div class="card-body">
                        <h5 class="card-title">Parfüm 2</h5>
                        <p class="card-text">Egy friss és üde illat, ami biztosan elnyeri a tetszésedet.</p>
                        <p class="card-text fw-bold">Ár: 200$</p>
                        <div class="d-flex gap-2">
                            <button class="btn btn-primary" onclick="addToCart('Parfüm 2', 200)">Kosárba helyezés</button>
                            <button class="btn btn-outline-secondary" onclick="reviewProduct('Parfüm 2')">Vélemények</button>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Termék 3 - férfi parfüm, ára 150 -->
            <div class="col-md-4 mb-4 product-card" data-gender="male" data-price="150">
                <div class="card">
                    <img src="images/parfume3.jpg" class="card-img-top" alt="Parfüm 3">
                    <div class="card-body">
                        <h5 class="card-title">Parfüm 3</h5>
                        <p class="card-text">Egy energikus és dinamikus illat, ami megújítja a napodat.</p>
                        <p class="card-text fw-bold">Ár: 150$</p>
                        <div class="d-flex gap-2">
                            <button class="btn btn-primary" onclick="addToCart('Parfüm 3', 150)">Kosárba helyezés</button>
                            <button class="btn btn-outline-secondary" onclick="reviewProduct('Parfüm 3')">Vélemények</button>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Termék 4 - unisex parfüm, ára 180 -->
            <div class="col-md-4 mb-4 product-card" data-gender="unisex" data-price="180">
                <div class="card">
                    <img src="images/parfume4.jpg" class="card-img-top" alt="Parfüm 4">
                    <div class="card-body">
                        <h5 class="card-title">Parfüm 4</h5>
                        <p class="card-text">Egy modern, egyedülálló unisex illat, amely egyaránt megfelel férfiaknak és nőknek.</p>
                        <p class="card-text fw-bold">Ár: 180$</p>
                        <div class="d-flex gap-2">
                            <button class="btn btn-primary" onclick="addToCart('Parfüm 4', 180)">Kosárba helyezés</button>
                            <button class="btn btn-outline-secondary" onclick="reviewProduct('Parfüm 4')">Vélemények</button>
                        </div>
                    </div>
                </div>
            </div>
            <!-- További termékek... -->
        </div>
    </main>

    <!-- Review Modal (Bootstrap modal) -->
    <div class="modal fade" id="reviewModal" tabindex="-1" aria-labelledby="reviewModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="reviewModalLabel">Vélemények - <span id="modalProductName"></span></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Bezár"></button>
                </div>
                <div class="modal-body">
                    <!-- Vélemények listája -->
                    <div id="reviewsList"></div>
                    <hr>
                    <!-- Vélemény írása -->
                    <div id="writeReviewSection">
                        <h6>Írj véleményt:</h6>
                        <div class="mb-2">
                            <label class="form-label">Értékelés:</label>
                            <select id="reviewRating" class="form-select" style="width: auto; display: inline-block;">
                                <option value="1">1 csillag</option>
                                <option value="2">2 csillag</option>
                                <option value="3">3 csillag</option>
                                <option value="4">4 csillag</option>
                                <option value="5" selected>5 csillag</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="reviewComment" class="form-label">Vélemény:</label>
                            <textarea id="reviewComment" class="form-control" rows="3"></textarea>
                        </div>
                        <button class="btn btn-primary" onclick="submitReview()">Vélemény beküldése</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Lábléc -->
    <footer class="text-center py-3">
        <p>&copy; 2025 Escentials</p>
    </footer>

    <!-- JavaScript fájlok -->
    <script src="js/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/waypoints/4.0.1/jquery.waypoints.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.js"></script>
    <script src="js/plugins.js"></script>
    <script src="js/script.js"></script>

    <!-- Kosárba helyezés funkció -->
    <script>
        function addToCart(productName, productPrice) {
            let cart = JSON.parse(localStorage.getItem('cart')) || [];
            const existingItem = cart.find(item => item.name === productName);
            if (existingItem) {
                existingItem.quantity++;
            } else {
                cart.push({
                    name: productName,
                    price: productPrice,
                    quantity: 1
                });
            }
            localStorage.setItem('cart', JSON.stringify(cart));
            alert(productName + " hozzáadva a kosárhoz!");
        }
    </script>

    <!-- Review funkciók -->
    <script>
        function reviewProduct(productName) {
            let currentUser = localStorage.getItem('currentUser');
            if (!currentUser) {
                alert("A vélemények megtekintéséhez kérlek jelentkezz be!");
                window.location.href = "login.php";
                return;
            }
            document.getElementById('modalProductName').textContent = productName;
            loadReviews(productName);
            if (!hasOrderedProduct(productName)) {
                document.getElementById('writeReviewSection').style.display = 'none';
            } else {
                document.getElementById('writeReviewSection').style.display = 'block';
            }
            const reviewModal = new bootstrap.Modal(document.getElementById('reviewModal'));
            reviewModal.show();
        }

        function loadReviews(productName) {
            const reviewsKey = "reviews_" + productName;
            let reviews = JSON.parse(localStorage.getItem(reviewsKey)) || [];
            const reviewsList = document.getElementById('reviewsList');
            if (reviews.length === 0) {
                reviewsList.innerHTML = "<p>Még nincs vélemény erre a termékre.</p>";
            } else {
                reviewsList.innerHTML = reviews.map(review => `
          <div class="mb-3">
            <strong>${review.username}</strong> - ${'★'.repeat(review.rating)}${'☆'.repeat(5 - review.rating)}
            <br>
            <small>${new Date(review.timestamp).toLocaleString()}</small>
            <p>${review.comment}</p>
          </div>
        `).join("");
            }
        }

        function hasOrderedProduct(productName) {
            let currentUser = JSON.parse(localStorage.getItem('currentUser'));
            if (!currentUser || !currentUser.email) return false;
            const ordersKey = "orders_" + currentUser.email;
            let orders = JSON.parse(localStorage.getItem(ordersKey)) || [];
            return orders.some(order => order.items.some(item => item.name === productName));
        }

        function submitReview() {
            const productName = document.getElementById('modalProductName').textContent;
            const rating = parseInt(document.getElementById('reviewRating').value);
            const comment = document.getElementById('reviewComment').value.trim();
            if (comment === "") {
                alert("Kérjük, írd meg a véleményedet!");
                return;
            }
            let currentUser = JSON.parse(localStorage.getItem('currentUser'));
            const review = {
                username: currentUser.username,
                rating: rating,
                comment: comment,
                timestamp: new Date().toISOString()
            };
            const reviewsKey = "reviews_" + productName;
            let reviews = JSON.parse(localStorage.getItem(reviewsKey)) || [];
            reviews.push(review);
            localStorage.setItem(reviewsKey, JSON.stringify(reviews));
            loadReviews(productName);
            document.getElementById('reviewComment').value = "";
            alert("Véleményed sikeresen elmentve!");
        }
    </script>

    <!-- Szűrő filter script (gender és ár rendezés) -->
    <script>
        let originalCards = [];

        document.addEventListener("DOMContentLoaded", function () {
            const container = document.getElementById('productsRow');
            // Tároljuk az eredeti termék kártyákat egyszer, hogy a szűrés ne essen el
            originalCards = Array.from(container.querySelectorAll('.product-card'));
        });

        // Szűrés és rendezés mindkét select változásakor
        document.getElementById('genderFilter').addEventListener('change', filterAndSortProducts);
        document.getElementById('priceSort').addEventListener('change', filterAndSortProducts);

        function filterAndSortProducts() {
            const genderFilter = document.getElementById('genderFilter').value;
            const priceSort = document.getElementById('priceSort').value;
            const container = document.getElementById('productsRow');

            // Szűrés az eredeti kártyák alapján
            let filteredCards = originalCards.filter(card => {
                const gender = card.getAttribute('data-gender');
                return (genderFilter === 'all' || gender === genderFilter);
            });

            // Ár szerinti rendezés, ha szükséges
            if (priceSort === 'asc') {
                filteredCards.sort((a, b) => parseFloat(a.getAttribute('data-price')) - parseFloat(b.getAttribute('data-price')));
            } else if (priceSort === 'desc') {
                filteredCards.sort((a, b) => parseFloat(b.getAttribute('data-price')) - parseFloat(a.getAttribute('data-price')));
            }

            // Töröljük a jelenlegi tartalmat, majd hozzáadjuk a szűrt, rendezett kártyákat
            container.innerHTML = '';
            filteredCards.forEach(card => container.appendChild(card));
        }
    </script>
</body>

</html>
HTML;
?>