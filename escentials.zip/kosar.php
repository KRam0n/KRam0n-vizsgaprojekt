<?php
include("config.php");

echo <<<'HTML'
<!DOCTYPE html>
<html lang="hu">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Kosár - Escentials</title>
    <!-- SEO meta tag-ek -->
    <meta name="description" content="Escentials - Fedezd fel a legjobb parfümöket, melyek garantáltan elvarázsolnak. Kiváló minőség, egyedi illatkompozíciók.">
    <meta name="keywords" content="parfüm, illat, luxus, Escentials, drogéria, minőségi parfüm">
    <meta name="author" content="Escentials">
    <!-- Linkek, stílusok -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.css" />
    <link rel="stylesheet" type="text/css" href="css/vendor.css">
    <link rel="stylesheet" type="text/css" href="style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:wght@200;300;400;500;600;700&family=Jost:wght@200;300;400;500&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
</head>
<!-- Bootstrap CSS, Swiper CSS, Egyéb stílusok ismétlése (ha szükséges) -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.css" />
<link rel="stylesheet" type="text/css" href="css/vendor.css">
<link rel="stylesheet" type="text/css" href="style.css">
<!-- Google Fonts & Font Awesome -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:wght@200;300;400;500;600;700&family=Jost:wght@200;300;400;500&display=swap" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
</head>

<body class="bg-body" data-bs-spy="scroll" data-bs-target="#navbar" data-bs-root-margin="0px 0px -40%" data-bs-smooth-scroll="true" tabindex="0">

    <!-- Header és navigáció -->
    <header id="header" class="site-header text-white bg-primary fixed-top bg-black fixed">
        <nav id="header-nav" class="navbar navbar-expand-lg">
            <div class="container-fluid">
                <!-- Logó kép helyett szöveg -->
                <a class="navbar-brand" href="index.php"
                    style="background: transparent; color: white; font-size: 1.8rem; font-weight: bold;">
                    EScentials
                </a>
                <button class="navbar-toggler d-flex d-lg-none order-3 p-2 border-0 shadow-none" type="button"
                    data-bs-toggle="offcanvas" data-bs-target="#bdNavbar" aria-controls="bdNavbar" aria-expanded="false"
                    aria-label="Toggle navigation">
                    <svg class="navbar-icon" width="50" height="50">
                        <use xlink:href="#navbar-icon"></use>
                    </svg>
                </button>
                <div class="offcanvas offcanvas-end" tabindex="-1" id="bdNavbar" aria-labelledby="bdNavbarOffcanvasLabel">
                    <div class="offcanvas-header px-4 pb-0">
                        <!-- Ugyanez az offcanvas menüben -->
                        <a class="navbar-brand" href="index.php"
                            style="background: transparent; color: white; font-size: 1.8rem; font-weight: bold;">
                            EScentials
                        </a>
                        <button type="button" class="btn-close btn-close-black" data-bs-dismiss="offcanvas"
                            aria-label="Close" data-bs-target="#bdNavbar"></button>
                    </div>
                    <div class="offcanvas-body">
                        <ul class="navbar-nav justify-content-end flex-grow-1 gap-5 pe-3">
                            <li class="nav-item">
                                <a class="nav-link p-0" href="index.php">Kezdőlap</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link p-0" href="termekek.php">Termékek</a>
                            </li>
                            <!-- Kosár menüpont (aktív oldal) -->
                            <li class="nav-item">
                                <a class="nav-link p-0" href="cart.php">Kosár</a>
                            </li>
                            <!-- További menüpontok, pl. Rólunk, Kapcsolat, stb. -->
                        </ul>
                    </div>
                </div>
            </div>
        </nav>
    </header>

    <!-- Fő tartalom: Kosár megjelenítése -->
    <main class="container" style="margin-top: 120px;">
        <h1 class="mb-4">Kosár</h1>
        <div class="row">
            <!-- Bal oldali rész: Kosár tételek -->
            <div class="col-lg-8 mb-5">
                <div class="table-responsive">
                    <table class="table align-middle" id="cart-table">
                        <thead>
                            <tr>
                                <th scope="col">Termék</th>
                                <th scope="col" class="text-center">Egységár</th>
                                <th scope="col" class="text-center">Mennyiség</th>
                                <th scope="col" class="text-center">Összesen</th>
                                <th scope="col" class="text-end">Törlés</th>
                            </tr>
                        </thead>
                        <tbody id="cart-items">
                            <!-- Itt jelennek meg dinamikusan a kosár tételek -->
                        </tbody>
                    </table>
                </div>
                <a href="termekek.php" class="text-secondary">
                    &laquo; Vissza a termékekhez
                </a>
            </div>

            <!-- Jobb oldali rész: Összegzés, kupon, szállítás -->
            <div class="col-lg-4">
                <div class="p-4 border bg-light">
                    <h4 class="mb-3">Összegzés</h4>
                    <div class="mb-3">
                        <label for="shippingSelect" class="form-label">Szállítás</label>
                        <select id="shippingSelect" class="form-select">
                            <option value="0">Áruházi átvétel (0 Ft)</option>
                            <option value="1000">Futárszolgálat (1 000 Ft)</option>
                            <option value="2000">Expressz (2 000 Ft)</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="couponCode" class="form-label">Kuponkód</label>
                        <input type="text" class="form-control" id="couponCode" placeholder="Enter your code" />
                    </div>
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <span class="fs-5">Összesen:</span>
                        <span class="fs-4 fw-bold" id="cart-total">0 Ft</span>
                    </div>
                    <!-- Tovább gomb: eseménykezelő ellenőrzi, hogy a kosár üres-e -->
                    <a href="#" class="btn btn-dark w-100" id="checkoutBtn">Tovább</a>
                </div>
            </div>
        </div>
    </main>

    <!-- Lábléc -->
    <footer class="text-center py-3">
        <p>&copy; 2025 Escentials</p>
    </footer>

    <!-- Alapvető JS fájlok -->
    <script src="js/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.js"></script>
    <script src="js/plugins.js"></script>
    <script src="js/script.js"></script>

    <!-- Kosár kezelés -->
    <script>
        // A kosár betöltése és megjelenítése
        function loadCart() {
            let cart = JSON.parse(localStorage.getItem('cart')) || [];
            const cartItemsContainer = document.getElementById('cart-items');
            cartItemsContainer.innerHTML = '';

            cart.forEach((item, index) => {
                const { name, price, quantity } = item;
                const itemTotal = price * quantity;

                const tr = document.createElement('tr');
                tr.innerHTML = `
          <td>${name}</td>
          <td class="text-center">${price} Ft</td>
          <td class="text-center">
            <div class="d-flex justify-content-center align-items-center gap-2">
              <button class="btn btn-outline-secondary btn-sm" onclick="changeQuantity(${index}, -1)">-</button>
              <span>${quantity}</span>
              <button class="btn btn-outline-secondary btn-sm" onclick="changeQuantity(${index}, 1)">+</button>
            </div>
          </td>
          <td class="text-center">${itemTotal} Ft</td>
          <td class="text-end">
            <button class="btn btn-danger btn-sm" onclick="removeItem(${index})">
              <i class="fas fa-trash-alt"></i>
            </button>
          </td>
        `;
                cartItemsContainer.appendChild(tr);
            });

            updateTotal();
        }

        // Mennyiség változtatása
        function changeQuantity(index, delta) {
            let cart = JSON.parse(localStorage.getItem('cart')) || [];
            if (!cart[index]) return;

            cart[index].quantity += delta;
            if (cart[index].quantity < 1) {
                cart[index].quantity = 1;
            }
            localStorage.setItem('cart', JSON.stringify(cart));
            loadCart();
        }

        // Tétel törlése
        function removeItem(index) {
            let cart = JSON.parse(localStorage.getItem('cart')) || [];
            if (!cart[index]) return;

            cart.splice(index, 1);
            localStorage.setItem('cart', JSON.stringify(cart));
            loadCart();
        }

        // Összegzés frissítése
        function updateTotal() {
            let cart = JSON.parse(localStorage.getItem('cart')) || [];
            let subtotal = 0;
            cart.forEach(item => {
                subtotal += item.price * item.quantity;
            });

            const shipping = parseInt(document.getElementById('shippingSelect').value, 10) || 0;
            let total = subtotal + shipping;

            const couponCode = document.getElementById('couponCode').value.trim();
            if (couponCode === 'DISCOUNT10') {
                total = Math.round(total * 0.9);
            }

            document.getElementById('cart-total').textContent = `${total} Ft`;
        }

        // Eseményfigyelők beállítása
        document.getElementById('shippingSelect').addEventListener('change', updateTotal);
        document.getElementById('couponCode').addEventListener('input', updateTotal);

        // "Tovább" gomb eseménykezelése:
        // Ha a kosár üres, nem enged tovább, ellenkező esetben a checkout oldalra navigál
        document.getElementById('checkoutBtn').addEventListener('click', (e) => {
            e.preventDefault();
            let cart = JSON.parse(localStorage.getItem('cart')) || [];
            if (cart.length === 0) {
                alert('Nem lehet továbblépni, mert a kosarad üres!');
                return;
            }
            // Ha nem üres, a checkout oldalra navigálunk (például checkout.php)
            window.location.href = 'checkout.php';
        });

        // Kosár betöltése oldal betöltésekor
        window.addEventListener('DOMContentLoaded', loadCart);
    </script>
</body>

</html>
HTML;
?>