<?php
$servername = "localhost";
$username = "root";
$password = "";          // Ha nincs jelszó
$dbname = "escentials_db"; // Az imént létrehozott adatbázis neve

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Kapcsolódás sikertelen: " . $conn->connect_error);
}
?>