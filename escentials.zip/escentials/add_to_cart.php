<?php
session_start();
include("config.php");

if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    echo "Nem vagy bejelentkezve!";
    exit();
}

$user_id = $_SESSION['user_id'];
$product_id = intval($_POST['product_id']);
$price = floatval($_POST['price']);
// A termék nevét nem feltétlen szükséges menteni, mert a products tábla tartalmazza

// Ellenőrizzük, hogy a kosárban már szerepel-e ez a termék a felhasználónál
$stmt = $conn->prepare("SELECT id, quantity FROM cart WHERE user_id = ? AND product_id = ?");
$stmt->bind_param("ii", $user_id, $product_id);
$stmt->execute();
$result = $stmt->get_result();
if ($row = $result->fetch_assoc()) {
    // Ha már van, növeljük a mennyiséget
    $newQuantity = $row['quantity'] + 1;
    $stmt->close();
    $stmt = $conn->prepare("UPDATE cart SET quantity = ? WHERE id = ?");
    $stmt->bind_param("ii", $newQuantity, $row['id']);
    if ($stmt->execute()) {
        echo "ok";
    } else {
        echo "Hiba: " . $stmt->error;
    }
    $stmt->close();
    exit();
}
$stmt->close();

// Ha nincs, beszúrunk egy új sort
$quantity = 1;
$stmt = $conn->prepare("INSERT INTO cart (user_id, product_id, quantity, price) VALUES (?, ?, ?, ?)");
$stmt->bind_param("iiid", $user_id, $product_id, $quantity, $price);
if ($stmt->execute()) {
    echo "ok";
} else {
    echo "Hiba: " . $stmt->error;
}
$stmt->close();
?>