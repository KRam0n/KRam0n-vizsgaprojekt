<?php
// contact.php
session_start();
include("config.php");
$successMessage = "";
$errorMessage = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = trim($_POST["name"]);
    $email = trim($_POST["email"]);
    $subject = trim($_POST["subject"]);
    $message = trim($_POST["message"]);

    if (empty($name) || empty($email) || empty($subject) || empty($message)) {
        $errorMessage = "Minden mezőt kötelező kitölteni.";
    } else {
        // Küldjük el az emailt az escentials@gmail.com címre
        $to = "escentials@gmail.com";
        $emailSubject = "Új üzenet a Kapcsolat oldalon: " . $subject;
        $emailBody = "Név: " . $name . "\nEmail: " . $email . "\nÜzenet: " . $message;
        $headers = "From: " . $email . "\r\n" . "Reply-To: " . $email . "\r\n";

        if (mail($to, $emailSubject, $emailBody, $headers)) {
            $successMessage = "Köszönjük az üzenetedet!";
        } else {
            $errorMessage = "Hiba történt az üzenet elküldésekor. Kérjük, próbáld meg később.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="hu">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kapcsolat - Escentials</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: #f5f7fa;
            font-family: 'Josefin Sans', sans-serif;
        }

        .contact-section {
            margin-top: 80px;
            max-width: 1000px;
        }

        .contact-form,
        .contact-info {
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin-bottom: 30px;
        }

        .map-responsive {
            overflow: hidden;
            padding-bottom: 56.25%;
            position: relative;
            height: 0;
        }

        .map-responsive iframe {
            left: 0;
            top: 0;
            height: 100%;
            width: 100%;
            position: absolute;
            border: 0;
        }

        h1,
        h2,
        h3 {
            color: #333;
        }
    </style>
</head>

<body>
    <div class="container contact-section">
        <h1 class="text-center mb-5">Kapcsolat</h1>
        <div class="row">
            <!-- Kapcsolatfelvételi űrlap -->
            <div class="col-md-6">
                <div class="contact-form">
                    <?php if (!empty($successMessage)): ?>
                        <div class="alert alert-success"><?php echo $successMessage; ?></div>
                    <?php elseif (!empty($errorMessage)): ?>
                        <div class="alert alert-danger"><?php echo $errorMessage; ?></div>
                    <?php endif; ?>
                    <form action="contact.php" method="post">
                        <div class="mb-3">
                            <label for="name" class="form-label">Név</label>
                            <input type="text" class="form-control" id="name" name="name" required
                                value="<?php echo isset($name) ? htmlspecialchars($name) : ''; ?>">
                        </div>
                        <div class="mb-3">
                            <label for="email" class="form-label">Email cím</label>
                            <input type="email" class="form-control" id="email" name="email" required
                                value="<?php echo isset($email) ? htmlspecialchars($email) : ''; ?>">
                        </div>
                        <div class="mb-3">
                            <label for="subject" class="form-label">Tárgy</label>
                            <input type="text" class="form-control" id="subject" name="subject" required
                                value="<?php echo isset($subject) ? htmlspecialchars($subject) : ''; ?>">
                        </div>
                        <div class="mb-3">
                            <label for="message" class="form-label">Üzenet</label>
                            <textarea class="form-control" id="message" name="message" rows="5"
                                required><?php echo isset($message) ? htmlspecialchars($message) : ''; ?></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary w-100">Küldés</button>
                    </form>
                </div>
            </div>
            <!-- Elérhetőségi adatok és térkép -->
            <div class="col-md-6">
                <div class="contact-info">
                    <h2>Elérhetőségek</h2>
                    <p><strong>Email:</strong> <a href="mailto:escentials@gmail.com">escentials@gmail.com</a></p>
                    <p><strong>Telefonszám:</strong> <a href="tel:06304050607">06304050607</a></p>
                    <h3>Cím</h3>
                    <p>Budapest, Szent Imre utca 42</p>
                    <div class="map-responsive">
                        <iframe
                            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2686.9270346906623!2d19.06672031539323!3d47.47233877916067!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4741dcf2a9123456%3A0x123456789abcdef!2sSzent%20Imre%20utca%2042%2C%20Budapest!5e0!3m2!1shu!2shu!4v1618502211095!5m2!1shu!2shu"
                            allowfullscreen="" loading="lazy"></iframe>
                    </div>
                </div>
            </div>
        </div>
        <div class="text-center mt-4">
            <a href="index.php" class="btn btn-secondary">Főoldal</a>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>