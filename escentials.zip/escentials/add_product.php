<?php
session_start();
include("config.php");

// Ha nincs bejelentkezve, vagy nincs admin jogosultság, akkor hibaüzenet és visszalépés a főoldalra
if (!isset($_SESSION['user_id']) || !isset($_SESSION['is_admin']) || $_SESSION['is_admin'] !== true) {
    ?>
    <!DOCTYPE html>
    <html lang="hu">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Nincs jogosultság - Escentials</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
        <style>
            body {
                background: #f5f7fa;
                font-family: 'Josefin Sans', sans-serif;
            }

            .container {
                margin-top: 80px;
                max-width: 500px;
            }
        </style>
    </head>

    <body>
        <div class="container">
            <div class="alert alert-danger shadow-sm">
                <h4 class="alert-heading">Nincs jogosultság!</h4>
                <p>Az oldal megnyitása admin jogosultságot igényel.</p>
            </div>
            <a href="index.php" class="btn btn-secondary w-100">Főoldal</a>
        </div>
    </body>

    </html>
    <?php
    exit();
}

// Ha eljutottunk ide, akkor a felhasználó be van jelentkezve és admin jogosultsággal rendelkezik.
// HIBA / SIKER üzenetek tárolására
$successMessage = "";
$errorMessage = "";

// 1. Új termék hozzáadása
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["action"]) && $_POST["action"] === "add") {
    $name = trim($_POST["name"]);
    $description = trim($_POST["description"]);
    $price = floatval($_POST["price"]);
    $gender = $_POST["gender"];

    // Fájl feltöltés kezelése
    if (isset($_FILES["image"]) && $_FILES["image"]["error"] == 0) {
        $allowed = array("jpg" => "image/jpeg", "jpeg" => "image/jpeg", "png" => "image/png");
        $filename = $_FILES["image"]["name"];
        $filetype = $_FILES["image"]["type"];
        $filesize = $_FILES["image"]["size"];

        // Kiterjesztés ellenőrzése
        $ext = pathinfo($filename, PATHINFO_EXTENSION);
        if (!array_key_exists($ext, $allowed)) {
            $errorMessage = "Hibás fájltípus. Csak JPG, JPEG, PNG engedélyezett.";
        } else {
            // Fájlméret max 5MB
            $maxsize = 5 * 1024 * 1024;
            if ($filesize > $maxsize) {
                $errorMessage = "A fájl túl nagy! Maximum 5 MB lehet.";
            } else {
                // MIME típus ellenőrzése
                if (in_array($filetype, $allowed)) {
                    // Egyedi fájlnév generálása
                    $newFilename = uniqid() . "." . $ext;
                    $destination = __DIR__ . "/uploads/" . $newFilename;

                    if (!move_uploaded_file($_FILES["image"]["tmp_name"], $destination)) {
                        $errorMessage = "Hiba történt a fájl mentésekor.";
                    } else {
                        // Sikeres feltöltés, beszúrjuk az adatbázisba
                        $stmt = $conn->prepare("INSERT INTO products (name, description, price, image, gender) VALUES (?, ?, ?, ?, ?)");
                        if (!$stmt) {
                            $errorMessage = "Hiba a lekérdezés előkészítésekor: " . $conn->error;
                        } else {
                            $stmt->bind_param("ssdss", $name, $description, $price, $newFilename, $gender);
                            if ($stmt->execute()) {
                                $successMessage = "Termék sikeresen hozzáadva!";
                            } else {
                                $errorMessage = "Hiba történt: " . $stmt->error;
                            }
                            $stmt->close();
                        }
                    }
                } else {
                    $errorMessage = "Hibás fájltípus.";
                }
            }
        }
    } else {
        $errorMessage = "Kérjük, válassz képfájlt!";
    }
}

// 2. Termék törlése
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["action"]) && $_POST["action"] === "delete") {
    $product_id = intval($_POST["product_id"]);
    // Lekérdezzük a termék képének nevét a szerverről történő törléshez
    $stmt = $conn->prepare("SELECT image FROM products WHERE id = ?");
    $stmt->bind_param("i", $product_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $productData = $result->fetch_assoc();
    $stmt->close();

    if ($productData) {
        $imageName = $productData["image"];
        // Töröljük az adatbázisból
        $stmtDel = $conn->prepare("DELETE FROM products WHERE id = ?");
        $stmtDel->bind_param("i", $product_id);
        if ($stmtDel->execute()) {
            $successMessage = "Termék törölve (ID: $product_id).";
            // Töröljük a képfájlt is, ha létezik
            $filePath = __DIR__ . "/uploads/" . $imageName;
            if (file_exists($filePath)) {
                unlink($filePath);
            }
        } else {
            $errorMessage = "Hiba történt a törlés során: " . $stmtDel->error;
        }
        $stmtDel->close();
    } else {
        $errorMessage = "A megadott termék nem található.";
    }
}

// Lekérdezzük az összes terméket a táblázatos listához
$products = [];
$sql = "SELECT * FROM products ORDER BY id DESC";
$res = $conn->query($sql);
if ($res && $res->num_rows > 0) {
    $products = $res->fetch_all(MYSQLI_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="hu">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Termékek kezelése - Escentials</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet"
        crossorigin="anonymous">
    <style>
        body {
            background: #f5f7fa;
            font-family: 'Josefin Sans', sans-serif;
        }

        .container {
            margin-top: 80px;
        }

        .product-image {
            width: 60px;
            height: 60px;
            object-fit: cover;
            border-radius: 4px;
        }
    </style>
</head>

<body>
    <div class="container">
        <h1 class="mb-4">Termékek kezelése</h1>
        <!-- Főoldalra mutató gomb -->
        <a href="index.php" class="btn btn-secondary mb-3">Főoldal</a>

        <!-- Üzenetek megjelenítése -->
        <?php if (!empty($successMessage)): ?>
            <div class="alert alert-success"><?php echo $successMessage; ?></div>
        <?php endif; ?>
        <?php if (!empty($errorMessage)): ?>
            <div class="alert alert-danger"><?php echo $errorMessage; ?></div>
        <?php endif; ?>

        <!-- Új termék hozzáadása -->
        <h2 class="h4 mt-4">Új termék hozzáadása</h2>
        <form action="add_product.php" method="post" enctype="multipart/form-data" class="mb-5">
            <input type="hidden" name="action" value="add">
            <div class="mb-3">
                <label for="name" class="form-label">Termék neve</label>
                <input type="text" class="form-control" name="name" id="name" required>
            </div>
            <div class="mb-3">
                <label for="description" class="form-label">Leírás</label>
                <textarea class="form-control" name="description" id="description" rows="3" required></textarea>
            </div>
            <div class="mb-3">
                <label for="price" class="form-label">Ár</label>
                <input type="number" step="0.01" class="form-control" name="price" id="price" required>
            </div>
            <div class="mb-3">
                <label for="gender" class="form-label">Célcsoport</label>
                <select class="form-select" name="gender" id="gender" required>
                    <option value="male">Férfi</option>
                    <option value="female">Női</option>
                    <option value="unisex">Unisex</option>
                </select>
            </div>
            <div class="mb-3">
                <label for="image" class="form-label">Termék kép</label>
                <input type="file" class="form-control" name="image" id="image" required>
            </div>
            <button type="submit" class="btn btn-primary">Termék hozzáadása</button>
        </form>

        <!-- Meglévő termékek listázása -->
        <h2 class="h4">Meglévő termékek</h2>
        <?php if (count($products) === 0): ?>
            <p>Nincsenek termékek az adatbázisban.</p>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-striped align-middle">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Kép</th>
                            <th>Terméknév</th>
                            <th>Ár</th>
                            <th>Célcsoport</th>
                            <th>Leírás</th>
                            <th>Törlés</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($products as $prod): ?>
                            <tr>
                                <td><?php echo $prod["id"]; ?></td>
                                <td>
                                    <?php if (!empty($prod["image"])): ?>
                                        <img src="uploads/<?php echo htmlspecialchars($prod["image"]); ?>" alt=""
                                            class="product-image">
                                    <?php else: ?>
                                        <span class="text-muted">Nincs kép</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo htmlspecialchars($prod["name"]); ?></td>
                                <td><?php echo htmlspecialchars($prod["price"]); ?></td>
                                <td><?php echo htmlspecialchars($prod["gender"]); ?></td>
                                <td><?php echo htmlspecialchars($prod["description"]); ?></td>
                                <td>
                                    <form action="add_product.php" method="post" onsubmit="return confirm('Biztosan törlöd?');">
                                        <input type="hidden" name="action" value="delete">
                                        <input type="hidden" name="product_id" value="<?php echo $prod["id"]; ?>">
                                        <button type="submit" class="btn btn-danger btn-sm">Törlés</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</body>

</html>