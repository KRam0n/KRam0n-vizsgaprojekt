<?php
session_start();
include("config.php");

// Ha a felhasználó nincs bejelentkezve, irányítsd át a login.php oldalra
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Lekérjük a bejelentkezett felhasználó rendeléseit az orders táblából
$stmt = $conn->prepare("SELECT * FROM orders WHERE user_id = ? ORDER BY order_date DESC");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$orders = $result->fetch_all(MYSQLI_ASSOC);
$stmt->close();
?>

<!DOCTYPE html>
<html lang="hu">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profil - Escentials</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet"
        crossorigin="anonymous">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:wght@300;400;600&display=swap" rel="stylesheet">
    <!-- Egyedi stílusok -->
    <style>
        body {
            background: linear-gradient(135deg, #f5f7fa, #c3cfe2);
            font-family: 'Josefin Sans', sans-serif;
            color: #333;
        }

        .navbar-custom {
            background-color: #5d5c61;
        }

        .navbar-custom .navbar-brand,
        .navbar-custom .nav-link {
            color: #fff;
        }

        .navbar-custom .nav-link:hover {
            color: #f8b500;
        }

        main.container {
            margin-top: 120px;
        }

        h1,
        h2 {
            text-align: center;
            margin-bottom: 30px;
        }

        .order-card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            background-color: #fff;
            margin-bottom: 20px;
            transition: transform 0.2s ease;
        }

        .order-card:hover {
            transform: translateY(-3px);
        }

        .order-card .card-body {
            padding: 20px;
        }

        .order-card h5 {
            font-weight: 600;
            color: #5d5c61;
        }

        .order-card p {
            margin: 0;
            font-size: 0.95rem;
        }

        .order-card ul {
            list-style: none;
            padding: 0;
        }

        .order-card ul li {
            background: #f8f9fa;
            margin-bottom: 5px;
            padding: 5px 10px;
            border-radius: 5px;
        }
    </style>
</head>

<body>
    <!-- Navigációs sáv -->
    <nav class="navbar navbar-expand-lg navbar-custom fixed-top">
        <div class="container">
            <a class="navbar-brand" href="#">Escentials</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Navigáció megnyitása">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item"><a class="nav-link" href="index.php">Kezdőlap</a></li>
                    <li class="nav-item"><a class="nav-link" href="contact.php">Kapcsolat</a></li>
                    <li class="nav-item"><a class="nav-link" href="logout.php">Kilépés</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <main class="container">
        <h1>Profil</h1>
        <h2>Rendeléseim</h2>
        <div id="ordersContainer" class="row">
            <?php if (empty($orders)): ?>
                <p class="text-center">Nincs leadott rendelés.</p>
            <?php else: ?>
                <?php foreach ($orders as $order): ?>
                    <?php
                    // Formázott rendelés dátum
                    $orderDate = date("Y-m-d H:i:s", strtotime($order['order_date']));
                    // Ha nincs tárolva fizetési mód, megjelenítünk egy alapértelmezett értéket (például "Online fizetés")
                    $paymentMethod = isset($order['payment_method']) ? htmlspecialchars($order['payment_method']) : 'Online fizetés';
                    ?>
                    <div class="col-md-6">
                        <div class="card order-card">
                            <div class="card-body">
                                <h5 class="card-title">Rendelés dátuma: <?php echo $orderDate; ?></h5>
                                <p><strong>Fizetési mód:</strong> <?php echo $paymentMethod; ?></p>
                                <p><strong>Összeg:</strong> <?php echo htmlspecialchars($order['total']); ?>$</p>
                                <p><strong>Termékek:</strong></p>
                                <ul>
                                    <?php
                                    // Lekérjük az adott rendelés tételeit az order_items táblából
                                    $stmt_items = $conn->prepare("SELECT * FROM order_items WHERE order_id = ?");
                                    $stmt_items->bind_param("i", $order['id']);
                                    $stmt_items->execute();
                                    $result_items = $stmt_items->get_result();
                                    $items = $result_items->fetch_all(MYSQLI_ASSOC);
                                    $stmt_items->close();
                                    foreach ($items as $item):
                                        ?>
                                        <li>
                                            Termék ID: <?php echo htmlspecialchars($item['product_id']); ?>
                                            (x<?php echo htmlspecialchars($item['quantity']); ?>)
                                            <?php if (isset($item['price'])): ?>
                                                - <?php echo htmlspecialchars($item['price']); ?>$
                                            <?php endif; ?>
                                        </li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </main>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"
        crossorigin="anonymous"></script>
</body>

</html>