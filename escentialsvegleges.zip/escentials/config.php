<?php
$servername = "localhost";
$username = "escentials1";
$password = "Projekt2025";
$dbname = "escentials1";

$conn = mysqli_connect($servername, $username, $password, $dbname);

if (!$conn) {
    die("Kapcsolódási hiba: " . mysqli_connect_error());
}
?>