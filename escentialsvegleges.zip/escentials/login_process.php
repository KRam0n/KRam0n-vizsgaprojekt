<?php
// login_process.php
session_start();
include 'config.php'; // Itt legyen a DB-kapcsolat: $conn = new mysqli(...);

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    // Ellenőrizzük, hogy kitöltötte-e a mezőket
    if (empty($email) || empty($password)) {
        $_SESSION['error'] = "Kérjük, töltsd ki az összes mezőt!";
        header("Location: login.php");
        exit();
    }

    // Megnézzük, van-e ilyen email az adatbázisban
    $stmt = $conn->prepare("SELECT id, username, password, is_admin FROM users WHERE email = ?");
    if (!$stmt) {
        $_SESSION['error'] = "Hiba a lekérdezés előkészítése során: " . $conn->error;
        header("Location: login.php");
        exit();
    }

    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    // Ha nincs találat, akkor hibás email/jelszó
    if ($result->num_rows === 0) {
        $_SESSION['error'] = "Hibás email vagy jelszó!";
        $stmt->close();
        header("Location: login.php");
        exit();
    }

    // Ha van, lekérjük az adatsort
    $user = $result->fetch_assoc();
    $stmt->close();

    // Ellenőrizzük a jelszót (password_verify, ha password_hash-sel lett tárolva)
    if (!password_verify($password, $user['password'])) {
        $_SESSION['error'] = "Hibás email vagy jelszó!";
        header("Location: login.php");
        exit();
    }

    // Ha minden oké, bejelentkeztetjük a felhasználót
    $_SESSION['logged_in'] = true;
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['username'] = $user['username'];
    // Ellenőrizzük, hogy a felhasználó admin-e (feltételezzük, hogy az 'is_admin' mező az adatbázisban szerepel)
    $_SESSION['is_admin'] = (isset($user['is_admin']) && $user['is_admin'] == 1) ? true : false;
    // LocalStorage beállítása (JS-ből), majd átirányítás a főoldalra
    echo "<script>
            localStorage.setItem('currentUser', JSON.stringify({
                id: " . $user['id'] . ",
                username: '" . addslashes($user['username']) . "',
                email: '" . addslashes($email) . "'
            }));
            window.location.href = 'index.php';
          </script>";
    exit();
} else {
    // Ha valaki nem POST-tal hívta meg, pl. közvetlenül a böngészőbe írta, hibát adunk
    $_SESSION['error'] = "Hibás kérés!";
    header("Location: login.php");
    exit();
}
