<?php
session_start();
session_destroy(); // Törli a session-t

// LocalStorage törlése JavaScript segítségével, majd átirányítás
echo "<script>
    localStorage.removeItem('currentUser');
    window.location.href = 'index.php';
</script>";
exit();
?>