<?php
// Egy egyszeri script admin felhasználó létrehozásához (például create_admin.php)
include("config.php");

$adminEmail = 'admin@admin.com';
$adminUsername = 'admin';
// A jelszót hash-eljük (használhatod például a password_hash() függvényt)
$adminPassword = password_hash('admin', PASSWORD_DEFAULT);

// Ellenőrizd, hogy már létezik-e ilyen email
$stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
$stmt->bind_param("s", $adminEmail);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows == 0) {
    $stmt->close();
    // Ha nem létezik, beszúrjuk az admin fiókot, is_admin=1
    $stmt = $conn->prepare("INSERT INTO users (email, username, password, is_admin) VALUES (?, ?, ?, 1)");
    $stmt->bind_param("sss", $adminEmail, $adminUsername, $adminPassword);
    if ($stmt->execute()) {
        echo "Admin felhasználó sikeresen létrehozva.";
    } else {
        echo "Hiba történt az admin felhasználó létrehozása során: " . $stmt->error;
    }
    $stmt->close();
} else {
    echo "Az admin felhasználó már létezik.";
}
?>