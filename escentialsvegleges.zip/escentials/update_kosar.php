<?php
session_start();

include("config.php");

// Ha a login során NEM $_SESSION['user_id'] változóba mented az user ID-t, akkor itt cseréld le!
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true || !isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $cart_id = intval($_POST['cart_id'] ?? 0);
    $action = $_POST['action'] ?? '';

    // Lekérdezzük a kosár tételt
    $stmt = $conn->prepare("SELECT user_id, quantity FROM cart WHERE id = ?");
    $stmt->bind_param("i", $cart_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $cart_item = $result->fetch_assoc();
    $stmt->close();

    // Ha nincs ilyen tétel, vagy nem a bejelentkezett felhasználóé
    if (!$cart_item || $cart_item['user_id'] != $_SESSION['user_id']) {
        header("Location: kosar.php");
        exit();
    }

    $quantity = (int) $cart_item['quantity'];

    if ($action === 'increment') {
        $quantity++;
    } elseif ($action === 'decrement') {
        $quantity--;
        if ($quantity < 1) {
            $quantity = 1; // 0 vagy negatív helyett legalább 1
        }
    }

    // Frissítjük az adatbázisban
    $stmt = $conn->prepare("UPDATE cart SET quantity = ? WHERE id = ?");
    $stmt->bind_param("ii", $quantity, $cart_id);
    $stmt->execute();
    $stmt->close();
}

header("Location: kosar.php");
exit();
