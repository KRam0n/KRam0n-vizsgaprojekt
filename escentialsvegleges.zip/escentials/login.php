<?php
// login.php
session_start();

// Ha van tárolt hibaüzenet, elmentjük, majd töröljük
$error = $_SESSION['error'] ?? '';
unset($_SESSION['error']);

echo <<<'HTML'
<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, maximum-scale=1.0, user-scalable=no">
    <title>Bejelentkezés - Escentials</title>
    <!-- SEO meta tag-ek -->
    <meta name="description" content="Escentials - Fedezd fel a legjobb parfümöket, melyek garantáltan elvarázsolnak. Kiváló minőség, egyedi illatkompozíciók.">
    <meta name="keywords" content="parfüm, illat, luxus, Escentials, drogéria, minőségi parfüm">
    <meta name="author" content="Escentials">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" 
          integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.css" />
    <link rel="stylesheet" type="text/css" href="css/vendor.css">
    <link rel="stylesheet" type="text/css" href="style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:wght@200;300;400;500;600;700&family=Jost:wght@200;300;400;500&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">

    <style>
        body {
            background: #eee;
            margin: 0;
            padding: 0;
        }
        .custom-container {
            max-width: 400px;
            margin: 6rem auto;
            background: #fff;
            padding: 2rem;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            color: #000;
        }
        .custom-container h1 {
            font-size: 2rem;
            text-align: center;
            margin-bottom: 1.5rem;
        }
    </style>
</head>
<body>
    <div class="custom-container">
        <h1>Bejelentkezés</h1>
HTML;

// Ha van hiba, kiírjuk
if (!empty($error)) {
    echo '<div class="alert alert-danger" role="alert">';
    echo htmlspecialchars($error, ENT_QUOTES, 'UTF-8');
    echo '</div>';
}

echo <<<'HTML'
        <!-- A form a login_process.php-nak küldi az adatokat POST módszerrel -->
        <form action="login_process.php" method="POST">
            <div class="mb-3">
                <label for="email" class="form-label">Email cím</label>
                <input type="email" class="form-control" id="email" name="email" required>
            </div>
            <div class="mb-3">
                <label for="password" class="form-label">Jelszó</label>
                <input type="password" class="form-control" id="password" name="password" required>
            </div>
            <!-- A Bejelentkezés gombot btn-secondary-re állítjuk -->
            <button type="submit" class="btn btn-secondary w-100">Bejelentkezés</button>
        </form>

        <p class="text-center mt-3">
            <!-- Itt is btn-secondary-t használunk -->
            <a href="registration.php" class="btn btn-secondary w-100">
                Még nem regisztráltál? Regisztrálj most!
            </a>
        </p>
    </div>
    <!-- Eredeti designhoz tartozó scriptek -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
</body>
</html>
HTML;
?>