<?php
// register_process.php

include 'config.php'; // Csatlakozási adatok (mysqli)

// Csak akkor fut, ha POST-tal érkezik adat
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // 1) POST adatok kiolvasása
    $email = trim($_POST['email']);
    $username = trim($_POST['username']);
    $password = $_POST['password']; // a trim() nem mindig szükséges jelszónál

    // 2) Alap ellenőrzés
    if (empty($email) || empty($username) || empty($password)) {
        die("Minden mezőt ki kell tölteni!");
    }

    // 3) Megnézzük, hogy létezik-e már ilyen email az adatbázisban
    $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
    if (!$stmt) {
        die("Hiba a lekérdezés előkészítésekor: " . $conn->error);
    }
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();
    if ($stmt->num_rows > 0) {
        // Már létezik ez az email
        $stmt->close();
        die("Ez az email cím már regisztrálva van!");
    }
    $stmt->close();

    // 4) Jelszó hash-elése
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    // 5) Új felhasználó beszúrása
    $stmt = $conn->prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)");
    if (!$stmt) {
        die("Hiba a beszúrás előkészítésekor: " . $conn->error);
    }
    $stmt->bind_param("sss", $username, $email, $hashedPassword);

    if ($stmt->execute()) {
        // Siker esetén átirányítjuk a felhasználót a login.php oldalra
        $stmt->close();
        header("Location: login.php");
        exit();
    } else {
        die("Hiba a regisztráció során: " . $stmt->error);
    }
} else {
    die("Hibás kérés.");
}
