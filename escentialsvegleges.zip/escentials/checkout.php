<?php
session_start();
include("config.php");

// Ellenőrizzük, hogy a felhasználó be van-e jelentkezve
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$orderTotal = 0.0;

// 1) Alapértelmezésben lekérdezzük a kosár tartalmát és kiszámoljuk az összeget
$stmt = $conn->prepare("SELECT price, quantity FROM cart WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $orderTotal += $row['price'] * $row['quantity'];
}
$stmt->close();

// 2) Ha a felhasználó most küldi el a kuponkód űrlapot (apply_coupon), ellenőrizzük a kódot
$discountMessage = '';
if (isset($_POST['apply_coupon']) && !empty($_POST['coupon_code'])) {
    $enteredCode = trim($_POST['coupon_code']);
    // DISCOUNT10 kód esetén 10% kedvezményt adunk
    if (strcasecmp($enteredCode, 'DISCOUNT10') === 0) {
        $orderTotal = $orderTotal * 0.9;  // 10% kedvezmény
        $discountMessage = '10% kedvezmény érvényesítve!';
    } else {
        $discountMessage = 'Érvénytelen kuponkód!';
    }
}

// 3) Esetleg eltároljuk a kedvezményes végösszeget, hogy a form elküldésekor is megmaradjon
$_SESSION['order_total'] = $orderTotal;
?>
<!DOCTYPE html>
<html lang="hu">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <title>Fizetés - Escentials</title>
    <!-- SEO meta tag-ek -->
    <meta name="description" content="Escentials - Fedezd fel a legjobb parfümöket, melyek garantáltan elvarázsolnak.">
    <meta name="keywords" content="parfüm, illat, luxus, Escentials, drogéria, minőségi parfüm">
    <meta name="author" content="Escentials">

    <!-- Bootstrap CSS, Swiper, Egyéb stílusok, Google Fonts & Font Awesome -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.css" />
    <link rel="stylesheet" type="text/css" href="css/vendor.css" />
    <link rel="stylesheet" type="text/css" href="style.css" />
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
        href="https://fonts.googleapis.com/css2?family=Josefin+Sans:wght@200;300;400;500;600;700&family=Jost:wght@200;300;400;500&display=swap"
        rel="stylesheet" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet" />
</head>

<body class="bg-body" data-bs-spy="scroll" data-bs-target="#navbar" data-bs-root-margin="0px 0px -40%"
    data-bs-smooth-scroll="true" tabindex="0">

    <!-- Header és navigáció -->
    <header id="header" class="site-header text-white bg-primary fixed-top bg-black fixed">
        <nav id="header-nav" class="navbar navbar-expand-lg">
            <div class="container-fluid">
                <a class="navbar-brand" href="index.php"
                    style="background: transparent; color: white; font-size: 1.8rem; font-weight: bold;">
                    EScentials
                </a>
                <button class="navbar-toggler d-flex d-lg-none order-3 p-2 border-0 shadow-none" type="button"
                    data-bs-toggle="offcanvas" data-bs-target="#bdNavbar" aria-controls="bdNavbar" aria-expanded="false"
                    aria-label="Toggle navigation">
                    <svg class="navbar-icon" width="50" height="50">
                        <use xlink:href="#navbar-icon"></use>
                    </svg>
                </button>
                <div class="offcanvas offcanvas-end" tabindex="-1" id="bdNavbar"
                    aria-labelledby="bdNavbarOffcanvasLabel">
                    <div class="offcanvas-header px-4 pb-0">
                        <a class="navbar-brand" href="index.php"
                            style="background: transparent; color: white; font-size: 1.8rem; font-weight: bold;">
                            EScentials
                        </a>
                        <button type="button" class="btn-close btn-close-black" data-bs-dismiss="offcanvas"
                            aria-label="Close" data-bs-target="#bdNavbar"></button>
                    </div>
                    <div class="offcanvas-body">
                        <ul class="navbar-nav justify-content-end flex-grow-1 gap-5 pe-3">
                            <li class="nav-item">
                                <a class="nav-link p-0" href="index.php">Kezdőlap</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link p-0" href="termekek.php">Termékek</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link p-0" href="kosar.php">Kosár</a>
                            </li>
                            <!-- További menüpontok, ha szükséges -->
                        </ul>
                    </div>
                </div>
            </div>
        </nav>
    </header>

    <!-- Fő tartalom: Fizetési / Szállítási adatok -->
    <main class="container" style="margin-top: 120px;">
        <h1 class="mb-4">Fizetés</h1>
        <div class="row">
            <!-- Bal oldali rész: Vásárló adatainak űrlapja -->
            <div class="col-lg-8">
                <!-- A form a checkout_process.php-nak küldi a POST-ot -->
                <form id="checkoutForm" method="post" action="checkout_process.php">
                    <div class="mb-3">
                        <label for="full_name" class="form-label">Név</label>
                        <input type="text" class="form-control" id="full_name" name="full_name" placeholder="Teljes név"
                            required />
                    </div>
                    <div class="mb-3">
                        <label for="address" class="form-label">Szállítási cím</label>
                        <input type="text" class="form-control" id="address" name="address"
                            placeholder="Utca, házszám, város, irányítószám" required />
                    </div>
                    <div class="mb-3">
                        <label for="phone" class="form-label">Telefonszám</label>
                        <input type="tel" class="form-control" id="phone" name="phone" placeholder="+36..." required />
                    </div>
                    <hr class="my-4" />
                    <h4 class="mb-3">Fizetési mód</h4>
                    <div class="form-check mb-2">
                        <input class="form-check-input" type="radio" name="paymentMethod" id="cashOnDelivery"
                            value="utánvétes" checked />
                        <label class="form-check-label" for="cashOnDelivery">Utánvétes fizetés</label>
                    </div>
                    <div class="form-check mb-4">
                        <input class="form-check-input" type="radio" name="paymentMethod" id="creditCard"
                            value="bankkártyás" />
                        <label class="form-check-label" for="creditCard">Bankkártyás fizetés</label>
                    </div>
                    <!-- Bankkártyás űrlap mezők (alapértelmezetten rejtve, csak bankkártyás választásnál mutatjuk) -->
                    <div id="cardPaymentFields" style="display: none;">
                        <div class="mb-3">
                            <label for="cardNumber" class="form-label">Kártyaszám</label>
                            <input type="text" class="form-control" id="cardNumber" name="cardNumber"
                                placeholder="XXXX XXXX XXXX XXXX" />
                        </div>
                        <div class="row">
                            <div class="col mb-3">
                                <label for="cardExpiry" class="form-label">Lejárat (HH/ÉÉ)</label>
                                <input type="text" class="form-control" id="cardExpiry" name="cardExpiry"
                                    placeholder="MM/YY" />
                            </div>
                            <div class="col mb-3">
                                <label for="cardCVC" class="form-label">CVC</label>
                                <input type="text" class="form-control" id="cardCVC" name="cardCVC" placeholder="CVC" />
                            </div>
                        </div>
                    </div>
                    <!-- A végösszeget hidden inputban küldjük a checkout_process.php felé -->
                    <input type="hidden" name="order_total" id="order_total"
                        value="<?php echo htmlspecialchars($_SESSION['order_total']); ?>">

                    <button type="submit" class="btn btn-dark btn-lg w-100 mt-4">Fizetés</button>
                </form>
            </div>

            <!-- Jobb oldali rész: Rendelés összesítő + Kuponkód beváltása -->
            <div class="col-lg-4">
                <div class="p-4 border bg-light">
                    <h4 class="mb-3">Rendelés összesítő</h4>
                    <!-- Összesen (kedvezménnyel vagy anélkül) -->
                    <p class="fs-5">Összesen:
                        <strong><?php echo $_SESSION['order_total']; ?> $</strong>
                    </p>
                    <?php if (!empty($discountMessage)): ?>
                        <p class="text-success fw-bold"><?php echo $discountMessage; ?></p>
                    <?php endif; ?>

                    <!-- Kuponkód űrlap (ugyanerre az oldalra POST-ol) -->
                    <form method="POST" action="checkout.php">
                        <div class="mb-3">
                            <label for="coupon_code" class="form-label">Kuponkód</label>
                            <input type="text" class="form-control" id="coupon_code" name="coupon_code"
                                placeholder="Pl: DISCOUNT10" />
                        </div>
                        <button type="submit" name="apply_coupon" class="btn btn-secondary">Kupon beváltása</button>
                    </form>
                </div>
            </div>
        </div>
    </main>

    <!-- Lábléc -->
    <footer class="text-center py-3">
        <p>&copy; 2025 Escentials</p>
    </footer>

    <!-- JavaScript fájlok -->
    <script src="js/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.js"></script>
    <script src="js/plugins.js"></script>
    <script src="js/script.js"></script>

    <!-- Bankkártyás mezők mutatása/elrejtése -->
    <script>
        const cashOnDeliveryRadio = document.getElementById('cashOnDelivery');
        const creditCardRadio = document.getElementById('creditCard');
        const cardPaymentFields = document.getElementById('cardPaymentFields');

        function toggleCardFields() {
            if (creditCardRadio.checked) {
                cardPaymentFields.style.display = 'block';
            } else {
                cardPaymentFields.style.display = 'none';
            }
        }

        cashOnDeliveryRadio.addEventListener('change', toggleCardFields);
        creditCardRadio.addEventListener('change', toggleCardFields);
    </script>
</body>

</html>