<?php
session_start();
include("config.php");

// Ellenőrzés, hogy be van-e jelentkezve
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    die("Hibás kérés.");
}

// Formból érkező adatok
$full_name = trim($_POST['full_name']);
$address = trim($_POST['address']);
$phone = trim($_POST['phone']);
$paymentMethod = trim($_POST['paymentMethod']);
$orderTotal = floatval($_POST['order_total']);

// Ha bankkártyás fizetésnél további mezőket kérsz, pl.:
if ($paymentMethod === 'bankkártyás') {
    $cardNumber = trim($_POST['cardNumber'] ?? '');
    $cardExpiry = trim($_POST['cardExpiry'] ?? '');
    $cardCVC = trim($_POST['cardCVC'] ?? '');
    if (empty($cardNumber) || empty($cardExpiry) || empty($cardCVC)) {
        die("Kérjük, töltsd ki a kártyaadatokat!");
    }
    // Itt lehet további validáció...
}

// 1) Lekérdezzük a kosár tételeit
$stmt = $conn->prepare("SELECT * FROM cart WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$cart_items = $result->fetch_all(MYSQLI_ASSOC);
$stmt->close();

if (empty($cart_items)) {
    die("A kosarad üres!");
}

// 2) Rendelés beszúrása az orders táblába
$stmt = $conn->prepare("
    INSERT INTO orders (user_id, full_name, address, phone, total, payment_method)
    VALUES (?, ?, ?, ?, ?, ?)
");
if (!$stmt) {
    die("Hiba az orders beszúrásánál: " . $conn->error);
}
$stmt->bind_param("isssds", $user_id, $full_name, $address, $phone, $orderTotal, $paymentMethod);
if (!$stmt->execute()) {
    die("Hiba az orders beszúrásakor: " . $stmt->error);
}
$order_id = $stmt->insert_id;
$stmt->close();

// 3) A kosár tételeit átmásoljuk az order_items táblába
foreach ($cart_items as $item) {
    $product_id = $item['product_id'];
    $quantity = $item['quantity'];
    $price = $item['price'];

    $stmt = $conn->prepare("
        INSERT INTO order_items (order_id, product_id, quantity, price)
        VALUES (?, ?, ?, ?)
    ");
    if (!$stmt) {
        die("Hiba az order_items beszúrásánál: " . $conn->error);
    }
    $stmt->bind_param("iiid", $order_id, $product_id, $quantity, $price);
    if (!$stmt->execute()) {
        die("Hiba az order_items beszúrásakor: " . $stmt->error);
    }
    $stmt->close();
}

// 4) Kiürítjük a kosarat
$stmt = $conn->prepare("DELETE FROM cart WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$stmt->close();

// 5) Átirányítunk a főoldalra (vagy köszönőoldalra)
header("Location: index.php?order=success");
exit();
