<?php
session_start();
include("config.php");

header("Content-Type: application/json");

if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    echo json_encode(["ordered" => false]);
    exit();
}

$user_id = $_SESSION['user_id'];
$productName = $_GET['productName'] ?? '';

if (empty($productName)) {
    echo json_encode(["ordered" => false]);
    exit();
}

// Lekérdezzük, hogy a felhasználó rendelt-e már olyan terméket, melynek a neve megegyezik a megadottal
$query = "SELECT COUNT(*) as cnt 
          FROM orders o
          INNER JOIN order_items oi ON o.id = oi.order_id
          INNER JOIN products p ON oi.product_id = p.id
          WHERE o.user_id = ? AND p.name = ?";
$stmt = $conn->prepare($query);
if (!$stmt) {
    echo json_encode(["ordered" => false, "error" => $conn->error]);
    exit();
}
$stmt->bind_param("is", $user_id, $productName);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();
$stmt->close();

$ordered = ($row['cnt'] > 0);
echo json_encode(["ordered" => $ordered]);
exit();
?>