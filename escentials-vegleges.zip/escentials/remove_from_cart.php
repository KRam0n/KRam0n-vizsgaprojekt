<?php
session_start();
include("config.php");

if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header("Location: login.php");
    exit();
}

$cart_id = intval($_POST['cart_id'] ?? 0);

// Lekérdezzük a tételt
$stmt = $conn->prepare("SELECT user_id FROM cart WHERE id = ?");
$stmt->bind_param("i", $cart_id);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();
$stmt->close();

if (!$row || $row['user_id'] != $_SESSION['user_id']) {
    // Nincs ilyen tétel, vagy nem ehhez a felhasználóhoz tartozik
    header("Location: kosar.php");
    exit();
}

// Töröljük a tételt
$stmt = $conn->prepare("DELETE FROM cart WHERE id = ?");
$stmt->bind_param("i", $cart_id);
$stmt->execute();
$stmt->close();

header("Location: kosar.php");
exit();
?>