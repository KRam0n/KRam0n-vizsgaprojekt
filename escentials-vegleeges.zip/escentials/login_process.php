<?php
// login_process.php

session_start();
include 'config.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    // Ellenőrizzük, hogy kitöltötte-e a mezőket
    if (empty($email) || empty($password)) {
        die("Kérjük, töltsd ki az összes mezőt!");
    }

    // Lekérdezés: van-e ilyen email az adatbázisban?
    $stmt = $conn->prepare("SELECT id, username, password FROM users WHERE email = ?");
    if (!$stmt) {
        die("Hiba a lekérdezés előkészítése során: " . $conn->error);
    }
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        // Nincs ilyen email a táblában
        $stmt->close();
        die("Hibás email vagy jelszó!");
    }

    // Ha van találat, lekérjük az adatsort
    $user = $result->fetch_assoc();
    $stmt->close();

    // Ellenőrizzük a jelszót
    if (!password_verify($password, $user['password'])) {
        die("Hibás email vagy jelszó!");
    }

    // Bejelentkezés: session beállítása
    $_SESSION['logged_in'] = true;
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['username'] = $user['username'];

    // A localStorage-be a currentUser adat beállítása JavaScript segítségével,
    // majd a főoldalra való átirányítás.
    echo "<script>
            localStorage.setItem('currentUser', JSON.stringify({
                id: " . $user['id'] . ",
                username: '" . addslashes($user['username']) . "',
                email: '" . addslashes($email) . "'
            }));
            window.location.href = 'index.php';
          </script>";
    exit();
} else {
    die("Hibás kérés.");
}
?>