<?php
include("config.php");
?>
<!DOCTYPE html>
<html lang="hu">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Termékek - Escentials</title>
    <!-- SEO meta tag-ek -->
    <meta name="description"
        content="Escentials - Fedezd fel a legjobb parfümöket, melyek garantáltan elvarázsolnak. Kiváló minőség, egyedi illatkompozíciók.">
    <meta name="keywords" content="parfüm, illat, luxus, Escentials, drogéria, minőségi parfüm">
    <meta name="author" content="Escentials">
    <!-- Linkek, stílusok -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.css" />
    <link rel="stylesheet" type="text/css" href="css/vendor.css">
    <link rel="stylesheet" type="text/css" href="style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Josefin+Sans:wght@200;300;400;500;600;700&family=Jost:wght@200;300;400;500&display=swap"
        rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
</head>

<body class="bg-body" data-bs-spy="scroll" data-bs-target="#navbar" data-bs-root-margin="0px 0px -40%"
    data-bs-smooth-scroll="true" tabindex="0">
    <!-- Header és navigáció -->
    <header id="header" class="site-header text-white bg-primary fixed-top bg-black fixed">
        <nav id="header-nav" class="navbar navbar-expand-lg">
            <div class="container-fluid">
                <a class="navbar-brand" href="index.php"
                    style="background: transparent; color: white; font-size: 1.8rem; font-weight: bold;">
                    EScentials
                </a>
                <button class="navbar-toggler d-flex d-lg-none order-3 p-2 border-0 shadow-none" type="button"
                    data-bs-toggle="offcanvas" data-bs-target="#bdNavbar" aria-controls="bdNavbar" aria-expanded="false"
                    aria-label="Toggle navigation">
                    <svg class="navbar-icon" width="50" height="50">
                        <use xlink:href="#navbar-icon"></use>
                    </svg>
                </button>
                <div class="offcanvas offcanvas-end" tabindex="-1" id="bdNavbar"
                    aria-labelledby="bdNavbarOffcanvasLabel">
                    <div class="offcanvas-header px-4 pb-0">
                        <a class="navbar-brand" href="index.php"
                            style="background: transparent; color: white; font-size: 1.8rem; font-weight: bold;">
                            EScentials
                        </a>
                        <button type="button" class="btn-close btn-close-black" data-bs-dismiss="offcanvas"
                            aria-label="Close" data-bs-target="#bdNavbar"></button>
                    </div>
                    <div class="offcanvas-body">
                        <ul class="navbar-nav justify-content-end flex-grow-1 gap-5 pe-3">
                            <li class="nav-item">
                                <a class="nav-link p-0" href="index.php">Kezdőlap</a>
                            </li>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle p-0" href="#" id="accountDropdown" role="button"
                                    data-bs-toggle="dropdown" aria-expanded="false">
                                    <i class="fas fa-user"></i> Profil
                                </a>
                                <ul class="dropdown-menu" aria-labelledby="accountDropdown" id="accountMenu">
                                    <li><a class="dropdown-item" href="profile.php">Rendeléseim</a></li>
                                    <li><a class="dropdown-item" href="logout.php">Kilépés</a></li>
                                </ul>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link p-0" href="kosar.php">
                                    <i class="fas fa-shopping-cart"></i> Kosár
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </nav>
    </header>

    <!-- PHP rész a termékek lekérdezéséhez -->
    <?php
    // Lekérdezzük a termékeket a products táblából
    $query = "SELECT * FROM products";
    $result = $conn->query($query);
    ?>

    <main class="container my-lg-6" style="margin-top: 120px;">
        <h2 class="text-center mb-4">Parfüm Kínálat</h2>
        <!-- Szűrők -->
        <div class="mb-4 d-flex justify-content-center gap-3 flex-wrap">
            <select id="genderFilter" class="form-select w-auto">
                <option value="all" selected>Összes</option>
                <option value="male">Férfi parfümök</option>
                <option value="female">Női parfümök</option>
                <option value="unisex">Unisex parfümök</option>
            </select>
            <select id="priceSort" class="form-select w-auto">
                <option value="default" selected>Ár sorrend (alapértelmezett)</option>
                <option value="asc">Ár: Alacsony -> Magas</option>
                <option value="desc">Ár: Magas -> Alacsony</option>
            </select>
        </div>
        <div class="row" id="productsRow">
            <?php
            if ($result) {
                while ($row = $result->fetch_assoc()) {
                    $id = $row['id'];
                    $name = $row['name'];
                    $description = $row['description'];
                    $price = $row['price'];
                    $gender = $row['gender'];

                    // Kép elérési út – HA létezik, betöltjük, ellenkező esetben placeholder
                    $imageFile = $row['image'];
                    $imagePath = __DIR__ . '/uploads/' . $imageFile;
                    if (!empty($imageFile) && file_exists($imagePath)) {
                        // Ha van érvényes kép
                        $imgSrc = 'uploads/' . htmlspecialchars($imageFile);
                    } else {
                        // Nincs kép vagy nem létezik, placeholder
                        $imgSrc = 'uploads/placeholder.png';
                    }
                    // =============== LÉNYEG: Kártya egységes méret beállítása ===============
                    echo '<div class="col-md-4 mb-4 product-card" data-gender="' . htmlspecialchars($gender) . '" data-price="' . htmlspecialchars($price) . '">';
                    echo '  <div class="card h-100">';  // h-100: kitölti a rendelkezésre álló magasságot
                    echo '    <img src="' . $imgSrc . '" class="card-img-top" alt="' . htmlspecialchars($name) . '" style="height: 250px; object-fit: cover;">';
                    echo '    <div class="card-body d-flex flex-column justify-content-between">';
                    echo '      <h5 class="card-title">' . htmlspecialchars($name) . '</h5>';
                    echo '      <p class="card-text">' . htmlspecialchars($description) . '</p>';
                    echo '      <p class="card-text fw-bold">Ár: ' . htmlspecialchars($price) . '$</p>';
                    echo '      <div class="d-flex gap-2">';
                    echo '        <button class="btn btn-primary" onclick="addToCart(' . $id . ', \'' . addslashes($name) . '\',' . htmlspecialchars($price) . ')">Kosárba helyezés</button>';
                    echo '        <button class="btn btn-outline-secondary" onclick="reviewProduct(\'' . addslashes($name) . '\')">Vélemények</button>';
                    echo '      </div>';
                    echo '    </div>';
                    echo '  </div>';
                    echo '</div>';
                }
            }
            ?>
        </div>
    </main>

    <!-- Review Modal (ugyanaz, mint korábban) -->
    <div class="modal fade" id="reviewModal" tabindex="-1" aria-labelledby="reviewModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="reviewModalLabel">Vélemények - <span id="modalProductName"></span></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Bezár"></button>
                </div>
                <div class="modal-body">
                    <div id="reviewsList"></div>
                    <hr>
                    <div id="writeReviewSection">
                        <h6>Írj véleményt:</h6>
                        <div class="mb-2">
                            <label class="form-label">Értékelés:</label>
                            <select id="reviewRating" class="form-select" style="width: auto; display: inline-block;">
                                <option value="1">1 csillag</option>
                                <option value="2">2 csillag</option>
                                <option value="3">3 csillag</option>
                                <option value="4">4 csillag</option>
                                <option value="5" selected>5 csillag</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="reviewComment" class="form-label">Vélemény:</label>
                            <textarea id="reviewComment" class="form-control" rows="3"></textarea>
                        </div>
                        <button class="btn btn-primary" onclick="submitReview()">Vélemény beküldése</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="text-center py-3">
        <p>&copy; 2025 Escentials</p>
    </footer>

    <!-- JavaScript fájlok -->
    <script src="js/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.js"></script>
    <script src="js/plugins.js"></script>
    <script src="js/script.js"></script>

    <!-- AJAX alapú kosárba helyezés -->
    <script>
        function addToCart(productId, productName, productPrice) {
            $.ajax({
                url: 'add_to_cart.php',
                method: 'POST',
                data: { product_id: productId, name: productName, price: productPrice },
                success: function (response) {
                    alert(productName + " hozzáadva a kosárhoz!");
                },
                error: function () {
                    alert("Hiba történt a kosárba helyezés során.");
                }
            });
        }

        // A review funkciók
        function reviewProduct(productName) {
            // Először ellenőrizzük, hogy a felhasználó be van-e jelentkezve (localStorage-ben tárolva)
            let currentUser = localStorage.getItem('currentUser');
            if (!currentUser) {
                alert("A vélemények megtekintéséhez kérlek jelentkezz be!");
                window.location.href = "login.php";
                return;
            }

            // AJAX hívás a check_ordered.php-hoz, hogy megnézzük, a felhasználó rendelt-e már ebből a termékből
            $.ajax({
                url: 'check_ordered.php',
                method: 'GET',
                data: { productName: productName },
                dataType: 'json',
                success: function (response) {
                    // Ha a válasz szerint a terméket még nem rendelte meg, elrejtjük a véleményírási részt
                    if (!response.ordered) {
                        document.getElementById('writeReviewSection').style.display = 'none';
                    } else {
                        document.getElementById('writeReviewSection').style.display = 'block';
                    }
                    document.getElementById('modalProductName').textContent = productName;
                    loadReviews(productName);
                    const reviewModal = new bootstrap.Modal(document.getElementById('reviewModal'));
                    reviewModal.show();
                },
                error: function () {
                    alert("Hiba történt az ellenőrzés során.");
                }
            });
        }

        // Szűrés és rendezés – eredeti logika
        let originalCards = [];
        document.addEventListener("DOMContentLoaded", function () {
            const container = document.getElementById('productsRow');
            originalCards = Array.from(container.querySelectorAll('.product-card'));
        });
        document.getElementById('genderFilter').addEventListener('change', filterAndSortProducts);
        document.getElementById('priceSort').addEventListener('change', filterAndSortProducts);

        function filterAndSortProducts() {
            const genderFilter = document.getElementById('genderFilter').value;
            const priceSort = document.getElementById('priceSort').value;
            const container = document.getElementById('productsRow');
            let filteredCards = originalCards.filter(card => {
                const gender = card.getAttribute('data-gender');
                return (genderFilter === 'all' || gender === genderFilter);
            });
            if (priceSort === 'asc') {
                filteredCards.sort((a, b) => parseFloat(a.getAttribute('data-price')) - parseFloat(b.getAttribute('data-price')));
            } else if (priceSort === 'desc') {
                filteredCards.sort((a, b) => parseFloat(b.getAttribute('data-price')) - parseFloat(a.getAttribute('data-price')));
            }
            container.innerHTML = '';
            filteredCards.forEach(card => container.appendChild(card));
        }

        // Review funkciók
        function loadReviews(productName) {
            const reviewsKey = "reviews_" + productName;
            let reviews = JSON.parse(localStorage.getItem(reviewsKey)) || [];
            const reviewsList = document.getElementById('reviewsList');
            if (reviews.length === 0) {
                reviewsList.innerHTML = "<p>Még nincs vélemény erre a termékre.</p>";
            } else {
                reviewsList.innerHTML = reviews.map(review => `
          <div class="mb-3">
            <strong>\${review.username}</strong> - \${'★'.repeat(review.rating)}\${'☆'.repeat(5 - review.rating)}
            <br>
            <small>\${new Date(review.timestamp).toLocaleString()}</small>
            <p>\${review.comment}</p>
          </div>
        `).join("");
            }
        }

        function hasOrderedProduct(productName) {
            let currentUser = JSON.parse(localStorage.getItem('currentUser'));
            if (!currentUser || !currentUser.email) return false;
            const ordersKey = "orders_" + currentUser.email;
            let orders = JSON.parse(localStorage.getItem(ordersKey)) || [];
            return orders.some(order => order.items && order.items.some(item => item.name === productName));
        }

        function submitReview() {
            const productName = document.getElementById('modalProductName').textContent;
            const rating = parseInt(document.getElementById('reviewRating').value);
            const comment = document.getElementById('reviewComment').value.trim();
            if (comment === "") {
                alert("Kérjük, írd meg a véleményedet!");
                return;
            }
            let currentUser = JSON.parse(localStorage.getItem('currentUser'));
            const review = {
                username: currentUser.username,
                rating: rating,
                comment: comment,
                timestamp: new Date().toISOString()
            };
            const reviewsKey = "reviews_" + productName;
            let reviews = JSON.parse(localStorage.getItem(reviewsKey)) || [];
            reviews.push(review);
            localStorage.setItem(reviewsKey, JSON.stringify(reviews));
            loadReviews(productName);
            document.getElementById('reviewComment').value = "";
            alert("Véleményed sikeresen elmentve!");
        }
    </script>
</body>

</html>